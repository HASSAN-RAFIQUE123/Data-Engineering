# SequentailExeUsingDocker

### How to run

1. Clone the repository
```
git clone https://github.com/vishalsingh17/SequentailExeUsingDocker
```

2. Change the directory to SequentailExeUsingDocker.

3. Create the user using the command below
```
docker-compose up airflow-init
```
4. Turn up your docker compose file
```
docker-compose up
```

5. Open "localhost:8081" in your brower and the the credentials as user = admin and password = airflow
